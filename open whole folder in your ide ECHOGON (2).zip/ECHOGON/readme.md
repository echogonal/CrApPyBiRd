#Credits to CodeWithHarry for inspiration
#I just read the cwh code before making this to get the basic idea
#Also his game is a bit better thn my one caz he is a expert
#most importantly i got all the img by some randome dude on discord